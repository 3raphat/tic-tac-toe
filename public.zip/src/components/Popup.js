import React from 'react'

function Popup() {
  return (
    <div>Popup</div>
  )
}

export default Popup